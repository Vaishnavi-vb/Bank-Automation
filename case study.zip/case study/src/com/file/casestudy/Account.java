package com.file.casestudy;

abstract public class Account {
	private long accNo;
	private String holderName;
	private double balance;
	

	abstract void deposite(double amount);

	abstract void withdraw(double amount);

	abstract void checkBalance();

	abstract void intrestRate();

	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(long accNo, String holderName, double balance) {
		super();
		this.accNo = accNo;
		this.holderName = holderName;
		this.balance = balance;
	}

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
}
