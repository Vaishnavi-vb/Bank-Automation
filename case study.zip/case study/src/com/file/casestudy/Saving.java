package com.file.casestudy;
import java.util.Scanner;

public class Saving extends Account{
      static double minBalance;
      protected static double intrestRate;
      
      public Saving() {
		// TODO Auto-generated constructor stub
	   }
     
	public Saving(long accNo,String name,double balance) {
		super(accNo,name,balance);
	}

	public static double getMinBalance() {
		return minBalance;
	}

	public static void setMinBalance(double minBalance) {
		Saving.minBalance = minBalance;
	}
	
	static void intializeMinBal() {
		minBalance=10000;
	}
	

	public static double getIntrestRate() {
		return intrestRate;
	}

	public static void setIntrestRate(double intrestRate) {
		Saving.intrestRate = intrestRate;
	}

	@Override
	void deposite(double amount) {
		this.setBalance(this.getBalance()+amount);
	}

	@Override
	void withdraw(double amount) {
		if(this.getBalance()-amount<10000) {
			System.out.println("Withdrwal fail");
		}
		else {
			setBalance(this.getBalance()-amount);
			System.out.println("Succefully withdraw "+amount);
		}	
		
		rg[reportCount]=new Report(this.getAccNo(),this.getHolderName(),amount,"withdraw");
	}

	@Override
	void checkBalance() {
		System.out.println(this.getBalance());	
	}

	@Override
	void intrestRate() {
		double ir=this.getBalance()*(intrestRate/100);
		System.out.println("After a month you will get the "+ir+" on "+this.getBalance());	
	}

	
      
      
}
