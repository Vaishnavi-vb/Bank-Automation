package com.file.casestudy;
public class Loan extends Account {
       double loanGiven;
       double loanRepaid;
       static double intrestRate;
       
       public Loan() {
		// TODO Auto-generated constructor stub
	}
	public Loan(long accNo,String name,double bal) {
		super(accNo,name,bal);
		this.loanGiven = bal;
		this.loanRepaid =0;
		this.setBalance(0-bal);
	}
	public double getLoanGiven() {
		return loanGiven;
	}
	public void setLoanGiven(double loanGiven) {
		this.loanGiven = loanGiven;
	}
	public double getLoanRepaid() {
		return loanRepaid;
	}
	public void setLoanRepaid(double loanRepaid) {
		this.loanRepaid = loanRepaid;
	}
	@Override
	void deposite(double amount) {
		// TODO Auto-generated method stub
		if(this.getBalance()<0) {
			this.setBalance(this.getBalance()+amount);
		
		if(this.getBalance()<=0) {
			this.setBalance(this.getBalance()-amount);
			this.loanRepaid=amount;
		}
		else {
            // Loan fully repaid and additional funds as savings
            this.loanRepaid = amount - this.getBalance();; // Amount used to repay loan
            this.setBalance(this.getBalance()); // Remaining amount treated as savings
        }
    } else {
        // Handle case where there's no outstanding loan or negative balance
        // For example, simply add the deposit to the balance
        this.setBalance(this.getBalance() + amount);
    }
		
		
	}
	@Override
	void withdraw(double amount) {
		// TODO Auto-generated method stub
		if(this.getBalance()==0) {
			amount=amount*0.08+this.getBalance();
			this.setBalance(this.getBalance()-amount);
			this.loanGiven=amount;
		}
		else {
			System.out.println("you can't withdraw plz clear your last loan");
		}
		
	}
	@Override
	void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println(this.getBalance());
		
	}
	@Override
	void intrestRate() {
		// TODO Auto-generated method stub
		double ir = this.getBalance() * (intrestRate / 100);
		System.out.println("After a month you will get the " + ir + " on " + this.getBalance());
	}
	
       
}
