package com.file.casestudy;

public class Report {
    long accNo;
    String name;
    double balance;
    String activity;
    public Report() {
		// TODO Auto-generated constructor stub
	}
	public Report(long accNo, String name, double balance, String activity) {
		super();
		this.accNo = accNo;
		this.name = name;
		this.balance = balance;
		this.activity = activity;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
    
    
}
