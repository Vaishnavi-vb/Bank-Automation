package com.file.casestudy;

public class Current extends Account {
	static double overdraftLimit;
	double overdraftAmount;
	static double intrestRate;

	public Current() {
		overdraftLimit = 0;
		this.overdraftAmount = 0;
	}

	public Current(long accNo, String name, double balance) {
		super(accNo, name, balance);
		this.overdraftAmount = 0;
	}

	public static double getOverdraftLimit() {
		return overdraftLimit;
	}

	public static void setOverdraftLimit(double overdraftLimit) {
		overdraftLimit = overdraftLimit;
	}

	public double getOverdraftAmount() {
		return overdraftAmount;
	}

	public void setOverdraftAmount(double overdraftAmount) {
		this.overdraftAmount = overdraftAmount;
	}

	public static double getIntrestRate() {
		return intrestRate;
	}

	public static void setIntrestRate(double intrestRate) {
		Current.intrestRate = intrestRate;
	}

	static void intitializeOverdraftLmit() {
		overdraftLimit = 50000;
	}

	@Override
	void deposite(double amount) {
		if (this.getOverdraftAmount() == 0) {
			this.setBalance(this.getBalance() + amount);
			return;
		} else if (this.getOverdraftAmount() > amount) {
			setBalance(0);
			this.setOverdraftAmount(this.getOverdraftAmount() - amount);
		} else {
			double amt = amount - this.getOverdraftAmount();
			this.setBalance(amt);
			this.setOverdraftAmount(0);
		}
		setOverdraftAmount(getOverdraftLimit() - amount);
		System.out.println("you succesfully deposite " + amount);
		System.out.println("Your current overdraft limit is " + getOverdraftLimit());

	}

	@Override
	void withdraw(double amount) {
		if (amount <= this.getBalance()) {
			System.out.println("Withdrwal succesfull!!!!!!!!!!!!");
			this.setBalance(this.getBalance() - amount);
			return;
		} else if (overdraftAmount == 0) {
			if (getBalance() == 0) {
				if (amount <= getOverdraftLimit()) {
					if (getOverdraftAmount() == 0) {
						setOverdraftAmount(amount);
						setOverdraftLimit(getOverdraftLimit() - amount);
						return;
					} else {
						setOverdraftAmount(getOverdraftAmount() + amount);
						setOverdraftLimit(getOverdraftLimit() - amount);
						return;
					}
				} else {
					System.out.println("you will not able to withdrow " + amount);
					System.out.println("your withdraw limit is " + getOverdraftLimit());
				}
			}
		
		} else {
			this.setOverdraftAmount(amount - this.getBalance());
			setOverdraftLimit(this.getOverdraftLimit() - this.getOverdraftAmount());
			this.setBalance(0);

		}

	}

	@Override
	void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println(this.getBalance());
	}

	@Override
	void intrestRate() {
		// TODO Auto-generated method stub
		double ir = this.getBalance() * (intrestRate / 100);
		System.out.println("After a month you will get the " + ir + " on " + this.getBalance());
	}

}
