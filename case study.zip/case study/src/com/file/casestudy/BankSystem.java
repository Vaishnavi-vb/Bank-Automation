package com.file.casestudy;
import java.util.Scanner;
public class BankSystem {
       static int id;
       static int password;
       static private int accCount=0;
       static private int reportCount=0;
       int ano=100;
       Account acc;
       Account[] account=new Account[accCount];
      Report[] rg=new Report[reportCount];
      
       public BankSystem() {
    	    
	   }
       
      void createSavingAcc() {
    	  Scanner sc=new Scanner(System.in);
    	  System.out.println("Enter name");
    	  String nm=sc.nextLine();
    	  System.out.println("Enter balance");
    	  double bal=sc.nextDouble();
    	  if(bal<10000) {
    		  System.out.println("minimum balance should be 10000");
    	  }
    	  else {
    		  account[accCount++]=new Saving(ano,nm,bal);
    		   rg[reportCount++]=new Report(ano,nm,bal,"Saving Create");
			   ano++;
    	  }	    
      }
      
      void createSalaryAcc() {
    	  Scanner sc=new Scanner(System.in);
    	  System.out.println("Enter name");
    	  String nm=sc.nextLine();
    	  System.out.println("Enter balance");
    	  double bal=sc.nextDouble();
    	  if(bal<10000) {
    		  System.out.println("minimum balance should be 10000");
    	  }
    	  else {
    		  account[accCount++]=new Salary(ano++,nm,bal);
    		   rg[reportCount++]=new Report(ano,nm,bal,"Saving Create");
			   ano++;
    	  }  
      }
      
      void createCurrentAcc() {
    	  Scanner sc=new Scanner(System.in);
    	  System.out.println("Enter name");
    	  String nm=sc.nextLine();
    	  System.out.println("Enter balance");
    	  double bal=sc.nextDouble();
    	  account[accCount++]=new Current(ano++,nm,bal);
          rg[reportCount++]=new Report(ano,nm,bal,"Current Create");
		  ano++;
        }
      
      
      void createLoanAcc() {
    	  Scanner sc=new Scanner(System.in);
    	  System.out.println("Enter name");
    	  String nm=sc.nextLine();
    	  System.out.println("Enter balance");
    	  double bal=sc.nextDouble();
    	  account[accCount++]=new Loan(ano++,nm,bal); 
          rg[reportCount++]=new Report(ano,nm,bal,"Loan Create");
		  ano++;
      }
      
       
       }
      
}
