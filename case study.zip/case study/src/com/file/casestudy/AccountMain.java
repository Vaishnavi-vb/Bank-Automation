package com.file.casestudy;

import java.util.Scanner;

public class AccountMain {

	public static void main(String[] args) {

		AccountMain.performOperation();

	}

	static void performOperation() {
       BankSystem bs=new BankSystem();
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		do {
			System.out.println("----------------------------------------------------");
			System.out.println("| Choice |          Action                          |");
			System.out.println("----------------------------------------------------");
			System.out.println("|   1    |   withdraw                               |");
			System.out.println("----------------------------------------------------");
			System.out.println("|   2    |   deposite                               |");
			System.out.println("----------------------------------------------------");
			System.out.println("|   3    |   check balance                          |");
			System.out.println("----------------------------------------------------");
			System.out.println("|   4    |   Calculate interest rate                 |");
			System.out.println("----------------------------------------------------");
			System.out.println("|   5    |   activate account only for salary        |");
			System.out.println("----------------------------------------------------");
			System.out.println("|   6    |   Open Account                            |");
			System.out.println("----------------------------------------------------");
			System.out.println("|   7    |   close Account                           |");
			System.out.println("----------------------------------------------------");
			System.out.println("|   8    |   Generate report                         |");
			System.out.println("----------------------------------------------------");
			System.out.println("|   0    |   Exit                                    |");
			System.out.println("----------------------------------------------------");
			choice = sc.nextInt();
			Current.intitializeOverdraftLmit();
			switch (choice) {
			case 1: {
				System.out.println("Enetr amount to withdrw");
				double amount = sc.nextDouble();
				acc.withdraw(amount);
				rg[reportCount]=new Report(a.getAccNo(),a.getHolderName(),a.getBalance(),"Withdraw");
			}
				break;
			case 2: {
				System.out.println("Enetr amount to withdrw");
				double amount = sc.nextDouble();
				a.deposite(amount);
			}
				break;
			case 3: {
				a.checkBalance();
			}
				break;
			case 4: {
				a.intrestRate();
			}
				break;
			case 5: {

			}
				break;
			case 6: {
				AccountMain.chooseAccount();
			}
				break;
			case 7: {

			}
				break;
			case 8: {
				System.out.println("Enter id:");
				int id1 = sc.nextInt();
				System.out.println("Enter password:");
				int pass = sc.nextInt();

			}
				break;
			case 0: {
				System.out.println("Program end");
			}
				break;
			default: {
				System.out.println("Enter valid chioce");
			}
			}
		} while (choice != 0);
	}

	static void chooseAccount() {
		int choice = 0;
		BankSystem bs = new BankSystem();
		Scanner sc = new Scanner(System.in);
		do {

			System.out.println("+----------------------+");
			System.out.println("| Enter choice:        |");
			System.out.println("+----------------------+");
			System.out.println("| 1: Savings Account   |");
			System.out.println("| 2: Salary Account    |");
			System.out.println("| 3: Current Account   |");
			System.out.println("| 4: Loan Account      |");
			System.out.println("+----------------------+");

			choice = sc.nextInt();
			switch (choice) {
			case 1: {
				bs.createSavingAcc();
			}
				break;
			case 2: {
				bs.createSalaryAcc();
			}
				break;
			case 3: {
				bs.createCurrentAcc();
			}
				break;
			case 4: {
				bs.createLoanAcc();
			}
				break;
			default: {
				System.out.println("-------Enter valid choice------");
			}
			}
		} while (choice != 4);
	}

}
