package com.file.casestudy;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Salary extends Saving  {
    private LocalDate ltdate;
    private boolean status;
   
     public Salary() {
		// TODO Auto-generated constructor stub
	}
	public Salary(long accNo,String name,double balance) {
		super(accNo,name,balance);
		this.ltdate =LocalDate.now();
		this.status = status;
	}
	public LocalDate getLtdate() {
		return ltdate;
	}
	public void setLtdate(LocalDate ltdate) {
		this.ltdate = ltdate;
	}
	public boolean getStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	 public boolean isFrozen() {
	       return ChronoUnit.DAYS.between(this.ltdate, LocalDate.now()) > 60;
	    }
	 @Override
	void deposite(double amount) {
		this.setBalance(this.getBalance()+amount);
	 }
	@Override
	void withdraw(double amount) {
		String date="2024-05-15";
		this.ltdate=LocalDate.parse(date);
		this.diffDate(ltdate);
		if(this.status){
			System.out.println("your account is frozen!,you need to activate it frist");
		}
		else {
			super.withdraw(amount);    
		    this.ltdate=LocalDate.now();
	      }
	}
	
	@Override
	void checkBalance() {
		System.out.println(this.getBalance());	
	}
	
	@Override
	void intrestRate() {
		double ir=this.getBalance()*(intrestRate/100);
		System.out.println("After a month you will get the "+ir+" on "+this.getBalance());	
	}
	public void activeAccount() {
		if(status){
		    this.ltdate=LocalDate.now();
		    System.out.println("Your account has been activeted charges is debited from your account");
		    this.setBalance(this.getBalance()-500);
		}
		   System.out.println("Your account is currently active");
	}
	
	boolean diffDate(LocalDate currDate) {
    	 if(ChronoUnit.DAYS.between(this.ltdate, LocalDate.now())>60){
    		 return true;
    	 }
    	 else {
    		 return false;
    	 }
			 
     }
}
